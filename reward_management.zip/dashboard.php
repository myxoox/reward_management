<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

include 'db_connection.php';

// 获取统计数据
$total_donations = 0;
$total_amount = 0;

// 总捐赠记录数
$sql = "SELECT COUNT(*) as count FROM donations";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $total_donations = $row['count'];
}

// 总捐赠金额
$sql = "SELECT SUM(amount) as total FROM donations";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $total_amount = $row['total'] ?? 0;
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>数据大屏</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#165DFF',
                        secondary: '#36CFC9',
                        accent: '#722ED1',
                        dark: '#1D2129',
                        light: '#F2F3F5',
                    },
                    fontFamily: {
                        inter: ['Inter', 'sans-serif'],
                    },
                }
            }
        }
    </script>
    <style type="text/tailwindcss">
        @layer utilities {
            .content-auto {
                content-visibility: auto;
            }
            .sidebar-link {
                @apply flex items-center px-4 py-3 text-gray-600 hover:bg-primary/5 hover:text-primary rounded-lg transition-all duration-200;
            }
            .sidebar-link.active {
                @apply bg-primary/10 text-primary font-medium;
            }
            .card-hover {
                @apply transition-all duration-300 hover:shadow-lg hover:-translate-y-1;
            }
            .btn-primary {
                @apply bg-primary hover:bg-primary/90 text-white font-medium py-2 px-4 rounded-lg transition-all duration-200;
            }
            .btn-secondary {
                @apply bg-gray-200 hover:bg-gray-300 text-gray-700 font-medium py-2 px-4 rounded-lg transition-all duration-200;
            }
            .btn-danger {
                @apply bg-danger hover:bg-danger/90 text-white font-medium py-2 px-4 rounded-lg transition-all duration-200;
            }
        }
    </style>
</head>
<body class="bg-gray-50 font-inter">
    <div class="flex h-screen overflow-hidden">
        <!-- 侧边栏 -->
        <div class="hidden md:flex md:flex-col w-64 bg-white shadow-lg z-10 transition-all duration-300" id="sidebar">
            <div class="flex items-center justify-center h-16 border-b border-gray-200">
                <h1 class="text-xl font-bold text-primary">
                    <i class="fa fa-heart text-accent mr-2"></i> 管理系统
                </h1>
            </div>
            
            <div class="flex-1 overflow-y-auto py-4">
                <nav class="px-4 space-y-1">
                    <a href="dashboard.php" class="sidebar-link active">
                        <i class="fa fa-tachometer mr-3"></i> 数据大屏
                    </a>
                    <a href="donation_list.php" class="sidebar-link">
                        <i class="fa fa-list-alt mr-3"></i> 捐赠列表
                    </a>
                </nav>
            </div>
            
            <div class="p-4 border-t border-gray-200">
                <div class="flex items-center">
                    <div class="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center text-gray-600">
                        <i class="fa fa-user"></i>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm font-medium text-gray-700">管理员</p>
                        <p class="text-xs text-gray-500">admin@example.com</p>
                    </div>
                </div>
                <a href="logout.php" class="mt-4 flex items-center text-danger text-sm">
                    <i class="fa fa-sign-out mr-2"></i> 退出登录
                </a>
            </div>
        </div>

        <!-- 主内容 -->
        <div class="flex-1 flex flex-col overflow-hidden">
            <!-- 顶部导航栏 -->
            <header class="h-16 bg-white shadow-sm z-10 flex items-center justify-between px-4 md:px-6">
                <div class="flex items-center">
                    <button class="md:hidden text-gray-500 focus:outline-none" id="menu-toggle">
                        <i class="fa fa-bars text-xl"></i>
                    </button>
                    <h2 class="ml-4 text-lg font-medium text-gray-700 hidden md:block">数据大屏</h2>
                </div>
                
                <div class="flex items-center space-x-4">
                    <button class="relative text-gray-500 hover:text-primary transition-colors">
                        <i class="fa fa-bell text-xl"></i>
                        <span class="absolute -top-1 -right-1 w-4 h-4 bg-danger rounded-full flex items-center justify-center text-white text-xs">3</span>
                    </button>
                    
                    <div class="relative">
                        <button class="flex items-center focus:outline-none" id="user-menu-button">
                            <div class="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center text-gray-600">
                                <i class="fa fa-user"></i>
                            </div>
                            <span class="ml-2 text-sm font-medium text-gray-700 hidden md:block">管理员</span>
                            <i class="fa fa-angle-down ml-1 text-gray-500 hidden md:block"></i>
                        </button>
                        
                        <!-- 用户菜单 -->
                        <div class="hidden absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-1 z-50" id="user-menu">
                            <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                <i class="fa fa-user-circle mr-2"></i> 个人资料
                            </a>
                            <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                <i class="fa fa-cog mr-2"></i> 设置
                            </a>
                            <div class="border-t border-gray-100 my-1"></div>
                            <a href="logout.php" class="block px-4 py-2 text-sm text-danger hover:bg-gray-100">
                                <i class="fa fa-sign-out mr-2"></i> 退出登录
                            </a>
                        </div>
                    </div>
                </div>
            </header>
            
            <!-- 页面内容 -->
            <main class="flex-1 overflow-y-auto bg-gray-50 p-4 md:p-6">
                <div class="max-w-7xl mx-auto">
                    <!-- 统计卡片 -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                        <div class="bg-white rounded-xl shadow-sm p-6 card-hover">
                            <div class="flex items-center justify-between">
                                <div>
                                    <p class="text-sm font-medium text-gray-500">总捐赠人数</p>
                                    <h3 class="text-3xl font-bold text-gray-800 mt-1">
                                        <?php echo $total_donations; ?>
                                    </h3>
                                </div>
                                <div class="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
                                    <i class="fa fa-users text-xl"></i>
                                </div>
                            </div>
                            <div class="mt-4 flex items-center text-sm">
                                <span class="text-success flex items-center">
                                    <i class="fa fa-arrow-up mr-1"></i> 12.5%
                                </span>
                                <span class="text-gray-500 ml-2">相比上月</span>
                            </div>
                        </div>
                        
                        <div class="bg-white rounded-xl shadow-sm p-6 card-hover">
                            <div class="flex items-center justify-between">
                                <div>
                                    <p class="text-sm font-medium text-gray-500">总捐赠金额</p>
                                    <h3 class="text-3xl font-bold text-gray-800 mt-1">
                                        <?php echo "¥" . number_format($total_amount, 2); ?>
                                    </h3>
                                </div>
                                <div class="w-12 h-12 rounded-lg bg-secondary/10 flex items-center justify-center text-secondary">
                                    <i class="fa fa-rmb text-xl"></i>
                                </div>
                            </div>
                            <div class="mt-4 flex items-center text-sm">
                                <span class="text-success flex items-center">
                                    <i class="fa fa-arrow-up mr-1"></i> 18.2%
                                </span>
                                <span class="text-gray-500 ml-2">相比上月</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="bg-white rounded-xl shadow-sm overflow-hidden">
                        <div class="p-6 border-b border-gray-100 flex items-center justify-between">
                            <h3 class="text-lg font-medium text-gray-800">快捷操作</h3>
                        </div>
                        
                        <div class="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                            <a href="donation_list.php" class="flex items-center p-4 bg-primary/5 rounded-xl hover:bg-primary/10 transition-colors duration-200">
                                <div class="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary mr-4">
                                    <i class="fa fa-list-alt text-xl"></i>
                                </div>
                                <div>
                                    <h4 class="text-base font-medium text-gray-800">查看捐赠列表</h4>
                                    <p class="text-sm text-gray-500 mt-1">查看和管理所有捐赠记录</p>
                                </div>
                            </a>
                            
                            <a href="donation_list.php#add-donation-form" class="flex items-center p-4 bg-accent/5 rounded-xl hover:bg-accent/10 transition-colors duration-200">
                                <div class="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center text-accent mr-4">
                                    <i class="fa fa-plus text-xl"></i>
                                </div>
                                <div>
                                    <h4 class="text-base font-medium text-gray-800">添加捐赠记录</h4>
                                    <p class="text-sm text-gray-500 mt-1">快速添加新的捐赠记录</p>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script>
        // 移动端菜单切换
        document.getElementById('menu-toggle').addEventListener('click', function() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('hidden');
            sidebar.classList.toggle('fixed');
            sidebar.classList.toggle('inset-y-0');
            sidebar.classList.toggle('left-0');
            sidebar.classList.toggle('z-50');
        });
        
        // 用户菜单切换
        document.getElementById('user-menu-button').addEventListener('click', function() {
            const userMenu = document.getElementById('user-menu');
            userMenu.classList.toggle('hidden');
        });
        
        // 点击其他区域关闭用户菜单
        document.addEventListener('click', function(event) {
            const userMenuButton = document.getElementById('user-menu-button');
            const userMenu = document.getElementById('user-menu');
            
            if (!userMenuButton.contains(event.target) && !userMenu.contains(event.target)) {
                userMenu.classList.add('hidden');
            }
        });
    </script>
</body>
</html>