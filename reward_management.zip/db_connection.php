<?php
// 数据库连接配置
$servername = "localhost";
$username = "12345678";
$password = "zhongguodaxueshengkaifangluntan";
$dbname = "aifadian";

// 创建连接
$conn = new mysqli($servername, $username, $password, $dbname);

// 检查连接
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
}

// 设置字符集为UTF-8
$conn->set_charset("utf8");
?>