<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

include 'db_connection.php';

// 获取要编辑的记录ID
$edit_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($edit_id <= 0) {
    die("无效的记录ID");
}

// 查询记录
$sql = "SELECT * FROM donations WHERE id = $edit_id";
$result = $conn->query($sql);

if ($result->num_rows != 1) {
    die("记录不存在");
}

$row = $result->fetch_assoc();

// 处理编辑表单提交
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_donation'])) {
    $name = $_POST['name'];
    $region = $_POST['region'];
    $amount = $_POST['amount'];

    // 数据验证
    $errors = [];
    if (empty($name)) {
        $errors[] = "姓名不能为空";
    }
    if (empty($amount) || !is_numeric($amount) || $amount <= 0) {
        $errors[] = "请输入有效的金额";
    }
    
    if (!empty($errors)) {
        $error = implode("<br>", $errors);
    } else {
        // 防止SQL注入
        $name = $conn->real_escape_string($name);
        $region = $conn->real_escape_string($region);
        $amount = floatval($amount);
        
        // 更新记录（不更新ID和时间戳）
        $update_sql = "UPDATE donations 
                      SET name = '$name', 
                          region = '$region', 
                          amount = $amount 
                      WHERE id = $edit_id";
                      
        if ($conn->query($update_sql) === TRUE) {
            header("Location: donation_list.php");
            exit;
        } else {
            $error = "更新记录时出错: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>编辑捐赠记录</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#165DFF',
                        secondary: '#36CFC9',
                        accent: '#722ED1',
                        dark: '#1D2129',
                        light: '#F2F3F5',
                    },
                    fontFamily: {
                        inter: ['Inter', 'sans-serif'],
                    },
                }
            }
        }
    </script>
    <style type="text/tailwindcss">
        @layer utilities {
            .content-auto {
                content-visibility: auto;
            }
            .sidebar-link {
                @apply flex items-center px-4 py-3 text-gray-600 hover:bg-primary/5 hover:text-primary rounded-lg transition-all duration-200;
            }
            .sidebar-link.active {
                @apply bg-primary/10 text-primary font-medium;
            }
            .card-hover {
                @apply transition-all duration-300 hover:shadow-lg hover:-translate-y-1;
            }
            .btn-primary {
                @apply bg-primary hover:bg-primary/90 text-white font-medium py-2 px-4 rounded-lg transition-all duration-200;
            }
            .btn-secondary {
                @apply bg-gray-200 hover:bg-gray-300 text-gray-700 font-medium py-2 px-4 rounded-lg transition-all duration-200;
            }
            .btn-danger {
                @apply bg-danger hover:bg-danger/90 text-white font-medium py-2 px-4 rounded-lg transition-all duration-200;
            }
        }
    </style>
</head>
<body class="bg-gray-50 font-inter">
    <div class="flex h-screen overflow-hidden">
        <!-- 侧边栏 -->
        <div class="hidden md:flex md:flex-col w-64 bg-white shadow-lg z-10 transition-all duration-300" id="sidebar">
            <div class="flex items-center justify-center h-16 border-b border-gray-200">
                <h1 class="text-xl font-bold text-primary">
                    <i class="fa fa-heart text-accent mr-2"></i> 管理系统
                </h1>
            </div>
            
            <div class="flex-1 overflow-y-auto py-4">
                <nav class="px-4 space-y-1">
                    <a href="dashboard.php" class="sidebar-link">
                        <i class="fa fa-tachometer mr-3"></i> 数据大屏
                    </a>
                    <a href="donation_list.php" class="sidebar-link active">
                        <i class="fa fa-list-alt mr-3"></i> 捐赠列表
                    </a>
                </nav>
            </div>
            
            <div class="p-4 border-t border-gray-200">
                <div class="flex items-center">
                    <div class="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center text-gray-600">
                        <i class="fa fa-user"></i>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm font-medium text-gray-700">管理员</p>
                        <p class="text-xs text-gray-500">admin@example.com</p>
                    </div>
                </div>
                <a href="logout.php" class="mt-4 flex items-center text-danger text-sm">
                    <i class="fa fa-sign-out mr-2"></i> 退出登录
                </a>
            </div>
        </div>

        <!-- 主内容 -->
        <div class="flex-1 flex flex-col overflow-hidden">
            <!-- 顶部导航栏 -->
            <header class="h-16 bg-white shadow-sm z-10 flex items-center justify-between px-4 md:px-6">
                <div class="flex items-center">
                    <button class="md:hidden text-gray-500 focus:outline-none" id="menu-toggle">
                        <i class="fa fa-bars text-xl"></i>
                    </button>
                    <h2 class="ml-4 text-lg font-medium text-gray-700 hidden md:block">编辑捐赠记录</h2>
                </div>
                
                <div class="flex items-center space-x-4">
                    <button class="relative text-gray-500 hover:text-primary transition-colors">
                        <i class="fa fa-bell text-xl"></i>
                        <span class="absolute -top-1 -right-1 w-4 h-4 bg-danger rounded-full flex items-center justify-center text-white text-xs">3</span>
                    </button>
                    
                    <div class="relative">
                        <button class="flex items-center focus:outline-none" id="user-menu-button">
                            <div class="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center text-gray-600">
                                <i class="fa fa-user"></i>
                            </div>
                            <span class="ml-2 text-sm font-medium text-gray-700 hidden md:block">管理员</span>
                            <i class="fa fa-angle-down ml-1 text-gray-500 hidden md:block"></i>
                        </button>
                        
                        <!-- 用户菜单 -->
                        <div class="hidden absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-1 z-50" id="user-menu">
                            <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                <i class="fa fa-user-circle mr-2"></i> 个人资料
                            </a>
                            <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                <i class="fa fa-cog mr-2"></i> 设置
                            </a>
                            <div class="border-t border-gray-100 my-1"></div>
                            <a href="logout.php" class="block px-4 py-2 text-sm text-danger hover:bg-gray-100">
                                <i class="fa fa-sign-out mr-2"></i> 退出登录
                            </a>
                        </div>
                    </div>
                </div>
            </header>
            
            <!-- 页面内容 -->
            <main class="flex-1 overflow-y-auto bg-gray-50 p-4 md:p-6">
                <div class="max-w-7xl mx-auto">
                    <div class="bg-white rounded-xl shadow-sm p-6">
                        <div class="flex items-center justify-between mb-6">
                            <h3 class="text-xl font-bold text-gray-800">编辑捐赠记录</h3>
                            <a href="donation_list.php" class="text-gray-500 hover:text-gray-700">
                                <i class="fa fa-arrow-left mr-1"></i> 返回列表
                            </a>
                        </div>
                        
                        <?php if (isset($error)): ?>
                            <div class="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-lg mb-6">
                                <div class="flex items-center">
                                    <i class="fa fa-exclamation-circle mr-2"></i>
                                    <span><?php echo $error; ?></span>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . "?id=" . $edit_id; ?>">
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                                <div>
                                    <label for="name" class="block text-sm font-medium text-gray-700 mb-1">姓名</label>
                                    <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($row['name']); ?>" class="block w-full rounded-lg border-gray-300 shadow-sm focus:ring-primary focus:border-primary" placeholder="请输入姓名" required>
                                </div>
                                
                                <div>
                                    <label for="region" class="block text-sm font-medium text-gray-700 mb-1">地区</label>
                                    <input type="text" id="region" name="region" value="<?php echo htmlspecialchars($row['region']); ?>" class="block w-full rounded-lg border-gray-300 shadow-sm focus:ring-primary focus:border-primary" placeholder="请输入地区">
                                </div>
                                
                                <div>
                                    <label for="amount" class="block text-sm font-medium text-gray-700 mb-1">金额</label>
                                    <input type="number" id="amount" name="amount" step="0.01" value="<?php echo htmlspecialchars($row['amount']); ?>" class="block w-full rounded-lg border-gray-300 shadow-sm focus:ring-primary focus:border-primary" placeholder="请输入金额" required>
                                </div>
                            </div>
                            
                            <div class="mt-6 flex justify-end">
                                <a href="donation_list.php" class="btn-secondary mr-3">
                                    <i class="fa fa-times mr-2"></i> 取消
                                </a>
                                <button type="submit" name="edit_donation" class="btn-primary">
                                    <i class="fa fa-save mr-2"></i> 保存修改
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script>
        // 移动端菜单切换
        document.getElementById('menu-toggle').addEventListener('click', function() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('hidden');
            sidebar.classList.toggle('fixed');
            sidebar.classList.toggle('inset-y-0');
            sidebar.classList.toggle('left-0');
            sidebar.classList.toggle('z-50');
        });
        
        // 用户菜单切换
        document.getElementById('user-menu-button').addEventListener('click', function() {
            const userMenu = document.getElementById('user-menu');
            userMenu.classList.toggle('hidden');
        });
        
        // 点击其他区域关闭用户菜单
        document.addEventListener('click', function(event) {
            const userMenuButton = document.getElementById('user-menu-button');
            const userMenu = document.getElementById('user-menu');
            
            if (!userMenuButton.contains(event.target) && !userMenu.contains(event.target)) {
                userMenu.classList.add('hidden');
            }
        });
    </script>
</body>
</html>