<?php
// 设置响应头
header('Content-Type: application/json');

// 数据库连接信息
$servername = "localhost"; // 假设数据库在本地
$username = "aifadian";
$password = "aifadian";
$dbname = "aifadian";

// 创建连接
$conn = new mysqli($servername, $username, $password, $dbname);

// 检查连接
if ($conn->connect_error) {
    die(json_encode(["error" => "连接失败: " . $conn->connect_error]));
}

// 处理搜索查询
if (isset($_GET['search'])) {
    $search = $conn->real_escape_string($_GET['search']);
    $sql = "SELECT id, name, region, amount, donation_time FROM donations WHERE name LIKE '%$search%' OR region LIKE '%$search%'";
} else {
    $sql = "SELECT id, name, region, amount, donation_time FROM donations";
}

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    echo json_encode($data);
} else {
    echo json_encode([]);
}

$conn->close();
?>